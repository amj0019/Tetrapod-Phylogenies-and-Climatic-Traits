setwd("Tetrapod_phylo_project")

###############################################################################
#the trees in this code were obtained from Salasin et al., 2019

## Before this session, please ensure that the following R packages are installed:

library(tidyverse)
library(geiger)
library(ape)
library(phytools)
library(caper)
library(viridis)
library(phangorn)

#tetra_data <- read.csv("results/tetrapod_precip_mean.csv")
tetra_data <- read.csv("results/tetrapod_precip_median.csv")
#remove na values
tetra_data <- na.omit(tetra_data)

## Check whether the names match in the data and the tree

tetra_tree <- read.tree("trees/100Tetrapoda_chronograms.tre")
tetra_tree1 <- maxCladeCred(tetra_tree)
is.null(tetra_tree1$edge.length)

#summary(tetra_tree)
check <- name.check(phy = tetra_tree1, data = tetra_data, 
                    data.names = tetra_data$X)
check

## Now, let's remove those mismatched species from the tree
mytree_tetra <- drop.tip(tetra_tree1, check$tree_not_data) 
str(mytree_tetra) # check (tips and nodes)

## And the same for the trait data, using a slightly different function
matches_tetra <- match(tetra_data$X, check$data_not_tree, nomatch = 0)
mydata_tetra <- subset(tetra_data, matches_tetra == 0)
glimpse(mydata_tetra) # check (rows)

## Check that everything matches
check_final <- name.check(phy = mytree_tetra, data = mydata_tetra, 
                          data.names = mydata_tetra$X)
check_final # should say ok!

# Verify
is.rooted(mytree_tetra)       # Should be TRUE
is.binary(mytree_tetra)       # Should be TRUE
is.ultrametric(mytree_tetra)  # Should be TRUE

#if the is.binary() result is FALSE then follow these steps

# Get the number of descendants for each internal node
desc_counts <- tabulate(mytree_tetra$edge[,1])

# Internal nodes that are polytomies (more than 2 descendants)
poly_nodes <- which(desc_counts > 2)
poly_nodes

tips_to_remove <- unique(unlist(
  lapply(poly_nodes, function(n) {
    Descendants(mytree_tetra, n, "tips")[[1]]
  })
))

#pruning to obtain new tree
mytree_tetra_pruned <- drop.tip(mytree_tetra, tips_to_remove)


# Verify
is.binary(mytree_tetra_pruned)       # Should be TRUE
is.ultrametric(mytree_tetra_pruned)  # Should be TRUE

# If the is.ultrametric() results are FALSE, follow these steps

#Force ultrametric tree
mytree_tetra_ultra <- force.ultrametric(mytree_tetra_pruned, method = "extend")

#summary(tetrapod tree)
check <- name.check(phy = mytree_tetra_ultra, data = tetra_data, 
                    data.names = tetra_data$X)
check

## Now, let's remove those mismatched species from the tree
mytree_tetra_ultra <- drop.tip(mytree_tetra_ultra, check$tree_not_data) 
str(mytree_tetra_ultra) # check (tips and nodes)

## And the same for the trait data, using a slightly different function
matches_tetra_ultra <- match(tetra_data$X, check$data_not_tree, nomatch = 0)
mydata_tetra_ultra <- subset(tetra_data, matches_tetra_ultra == 0)
glimpse(mydata_tetra_ultra) # check (rows)

## Check that everything matches
check_final <- name.check(phy = mytree_tetra_ultra, data = mydata_tetra_ultra, 
                          data.names = mydata_tetra_ultra$X)
check_final # should say ok!

#final check
## Check whether the tree is binary
is.binary(mytree_tetra_ultra) #Should be TRUE

## Check whether the tree is rooted 
is.rooted(mytree_tetra_ultra) #Should be TRUE

## Check whether the tree is ultrametric
is.ultrametric(mytree_tetra_ultra) #Should be TRUE


## First, let's take a look at the tree:
## Look at the tree summary:
mytree_tetra_ultra

## Plot the tree as a circular/fan phylogeny with small labels
plot(mytree_tetra_ultra, cex = 0.2, typ = "fan", no.margin = TRUE)
mydata_tetra_ultra

#changing the precipitation to Kelvin scale to avoid negative values (for log conversion)
mydata_tetra_ultra$precipitation <- mydata_tetra_ultra$precipitation + 273

## Let's do a quick check of the distribution of our data
## First, the raw continuous data:
p1 <- ggplot(mydata_tetra_ultra, aes(x = precipitation)) +
  geom_histogram(bins = 20, fill = "turquoise4") +
  theme_bw(base_size = 14)
p1 

## And now with it log-transformed:
p2 <- ggplot(mydata_tetra_ultra, aes(x = log(precipitation))) +
  geom_histogram(bins = 20, fill = "chartreuse4") +
  theme_bw(base_size = 14)
p2


## Take our trait of interest (i.e. precipitation) and log transform it:
logprecip <- log(pull(mydata_tetra_ultra, precipitation))
names(logprecip) <- mydata_tetra_ultra$X # give these values names (i.e. species names)
head(logprecip) # look at the first few rows


## Next, let's plot these trait data onto the phylogeny!

## Create "contMap" object using this log-transformed data:
tetra_contMap <- contMap(mytree_tetra_ultra, logprecip, 
                         plot=FALSE, res=200)

## Set up the colour gradient:
n <- length(tetra_contMap$cols) # number of colour breaks
tetra_contMap$cols[1:n] <- magma(n) # using the gradient 'viridis' ( = yellow to purple)

## Plot the tree:
plot(tetra_contMap, fsize = c(0.4, 1), outline = FALSE, lwd = c(3, 7), leg.txt = "precipitation (log)")

################################################################################

## Evolutionary model-fitting analysis to characterize the evolutionary mode of preciperature across the phylogeny

## Fit to two commonly used evolutionary models:
##      (1) the Brownian motion (BM) model 
##      (2) the single peak Ornstein-Uhlenbeck (OU) model

## We will use the same log-transformed precipitation data from above:
head(logprecip) # Look at the first few rows

## Reorder the tree and trait data so that they match:
mydata_tetra_ultra <- mydata_tetra_ultra[match(mytree_tetra_ultra$tip.label, mydata_tetra_ultra$X), ]

## Now let's fit our models!

## (1) Fit the Brownian model:

BM <- fitContinuous(mytree_tetra_ultra, logprecip, model = c("BM"))
BM # check the output 

## (2) Fit the Ornstein-Uhlenbeck (OU) model

OU <- fitContinuous(mytree_tetra_ultra, logprecip, model = c("OU"))
OU # check the output


## Now, let's compare the models using AIC 
## A lower 'fit' value indicates the preferred, or 'best' model:
AICscores <- setNames(c(BM$opt$aic, OU$opt$aic), c("BM","OU"))
aicw(AICscores)

################################################################################

## Phylogenetic signal
## Two popular methods for estimating phylogenetic signal:
##      1. Pagel’s λ (lambda)
##      2. Blomberg’s K

## Pagel’s λ (lambda):

lambdaprecip <- phylosig(mytree_tetra_ultra, logprecip, method = "lambda", test = TRUE)
lambdaprecip # take a look at the output

## Blomberg’s K:


Kprecip <- phylosig(mytree_tetra_ultra, logprecip, method = "K", test = TRUE, nsim = 1000)
Kprecip


################################################################################
  



