setwd("Tetrapod_phylo_project")

#the function, environment, distribution and data folders consist of codes and data that has been obtained from Saladin et al., 2019
library(geodata)
library(terra)
require(raster)
source("function/recstrat_prop.R")

# example for one taxon group ("amphibians" here):
spp     <- "amph"   #taxon group. Use "bird", "squa", and "mamm" for birds, squamates and mammals respectively
bio     <- "bio9"   #bioclimatic variable for this taxon group used in combination with MIND #bio6 for mammals and birds and bio5 for squamates.
km      <- 15       #resolution (other resolutions were used for robustness analyses, see Supp.Inf.)
pts     <- 10       #maximum number of sampled sites within a stratum
classes <- "99"     #number of classes in the stratification layer (9+9 classes in both layers)
delta   <- "010"    #delta transformation of phylogenies ("010" means: no transformation applied)
author  <- "Roquet" #data set matched with the Roquet et al. 2014 phylogenies

# Random stratified sampling - Sampling of local communities proportional to the log of the stratum area
#-------------------------------------------------------------------------------------------------------#
in_grid   <- raster(paste("environment/stratificationLayers/",spp,"_",bio,"_MIND_strat.tif",sep=""))
prop_pts1 <- recstrat_prop(in_grid, pts) 
saveRDS(prop_pts1,file=paste("results/prop.points_classes",classes,"_",spp,"_",bio,"_",km,"km.rds",sep=""))

# get community data for all points
stk_spp <- stack(paste("distribution/",spp,"_",km,"km.gri",sep=""))
pts_spp <- extract(stk_spp,prop_pts1[,1:2]) 
rd_com  <- cbind(prop_pts1,pts_spp)
saveRDS(rd_com,file=paste("results/rd_com_classes",classes,"_",spp,"_",bio,"_",km,"km.rds",sep=""))

#the above part of the code and the data used comes from Saladin et al., 2019
# =======================================================================================================

#amphibians
community_data <- readRDS("data/rd_com_classes99_amph_bio9_15km.rds")
reference_raster <- raster("environment/stratificationLayers/amph_bio9_MIND_strat.tif")

#mammals
#community_data <- readRDS("results/rd_com_classes99_mamm_bio6_15km.rds")
#reference_raster <- raster("environment/stratificationLayers/mamm_bio6_MIND_strat.tif")

#squamates
#community_data <- readRDS("results/rd_com_classes99_squa_bio5_15km.rds")
#reference_raster <- raster("environment/stratificationLayers/squa_bio5_MIND_strat.tif")

#birds
#community_data <- readRDS("results/rd_com_classes99_bird_bio6_15km.rds")
#reference_raster <- raster("environment/stratificationLayers/bird_bio6_MIND_strat.tif")

# WorldClim download
worldclim_bio <- worldclim_global(var = "bio", res = 10, path = tempdir())

# Convert SpatRaster to RasterLayer for compatibility
worldclim_bio1  <- raster(worldclim_bio[[1]])
worldclim_bio12 <- raster(worldclim_bio[[12]])

# --- Harmonization Steps ---

# 1. Reproject WorldClim raster to match the reference CRS
# The `projectRaster` function also handles resampling to the new grid

harmonized_bio1_amph <- projectRaster(from = worldclim_bio1, to = reference_raster, method = "bilinear")

#use the same command 'projectRaster(from = worldclim_bio1, to = reference_raster, method = "bilinear")' and create raster vectors for 
#mammals, birds and squamates. For example harmonized_bio1_mamm <- projectRaster(from = worldclim_bio1, to = reference_raster, method = "bilinear")

#for precipitation
#harmonized_bio12_amph <- projectRaster(from = worldclim_bio12, to = reference_raster, method = "bilinear")
#for other clades also follow similar process as mentioned above

# Now, 'harmonized_bio1_amph' has the same CRS, resolution, and extent as the study data.
# It is ready to use!

# 2. Save your new, aligned raster for future use
writeRaster(harmonized_bio1_amph, "bio1_harmonized_amph.tif")

#writeRaster(harmonized_bio1_mamm, "bio1_harmonized_mamm.tif")
#writeRaster(harmonized_bio1_squa, "bio1_harmonized_squa.tif")
#writeRaster(harmonized_bio1_bird, "bio1_harmonized_bird.tif")

# The extract() function needs the raster and a matrix of coordinates.
# We get the coordinates from the first two columns of your community_data data frame.
# The function will return a vector of temperature values, one for each point (row).
temperature_values <- raster::extract(harmonized_bio1_amph, community_data[, 1:2])

#precipitation
#precipitation_values <- raster::extract(harmonized_bio12_amph, community_data[, 1:2])

# Note: WorldClim bio1 (Annual Mean Temperature) is in degrees Celsius.

# We can now add this vector as a new column to your original data frame.
# This is often clearer than using cbind() as it gives the column a meaningful name directly.
community_data$bio1_temp <- temperature_values

#precipitation
#community_data$bio12_precip <- precipitation_values

# Check the first few rows of your updated data frame.
# You should see a new column named 'bio1_temp' at the end.
head(community_data)

# You can also get a statistical summary of the new column
# This is a good way to check for NAs (if any points fell outside the raster) and see the range of values.
summary(community_data$bio1_temp)

#precpitation
#summary(community_data$bio12_precip)

saveRDS(community_data, file="results/rd_com_with_temp_classes99_amph_bio9_15km.rds")
#saveRDS(community_data, file="results/rd_com_with_temp_classes99_mamm_bio6_15km.rds")
#saveRDS(community_data, file="results/rd_com_with_temp_classes99_bird_bio6_15km.rds")
#saveRDS(community_data, file="results/rd_com_with_temp_classes99_squa_bio5_15km.rds")

# You now have a single data frame containing:
# 1. Point coordinates (x, y)
# 2. Stratum ID
# 3. Species presence/absence data for each point
# 4. Annual mean temperature (bio1) for each point

write.csv(community_data,"results/amph_with_temp.csv")
#write.csv(community_data,"results/mamm_with_temp.csv")
#write.csv(community_data,"results/bird_with_temp.csv")
#write.csv(community_data,"results/squa_with_temp.csv")

#precipitation
#write.csv(community_data,"results/amph_with_precip.csv")

#treat as dataframe
amph_with_temp <- community_data[, -c(1, 2,3)]
col_no <- ncol(amph_with_temp)
amph_temp_summary <- data.frame(matrix(ncol = ncol(amph_with_temp), nrow = 1))
colnames(amph_temp_summary) <- colnames(amph_with_temp)
amph_temp_summary <- amph_temp_summary[,-col_no] #check what this 60 is
counter <- colnames(amph_temp_summary)

#for precipitation follow the same process just replace 'temp' with 'precip'

#do the same process by replacing 'amph' with 'mamm', 'squa' and 'bird' for rest of the taxa


#calculate summary statistic of temperature for each species
#choose required summary statistics by removing the comment

for (i in 1: length(counter)){
  subset <- amph_with_temp[which(amph_with_temp[,i]== 1),]
  #amph_temp_summary[,i] <- mean(subset$bio1_temp)
  amph_temp_summary[,i] <- median(subset$bio1_temp)
}

#for precipitation follow same process, replace 'temp' with 'precip'

amph_temp_summary_t <- as.data.frame(t(amph_temp_summary))
colnames(amph_temp_summary_t) <- c("temperature")
write.csv(amph_temp_summary_t, "results/amph_temp_summary_median.csv")
#write.csv(amph_temp_summary_t, "results/amph_temp_summary_mean.csv")

#for precipitation

#amph_precip_summary_t <- as.data.frame(t(amph_precip_summary))
#colnames(amph_precip_summary_t) <- c("precipitation")
#write.csv(amph_precip_summary_t, "results/amph_precip_summary_median.csv")
#write.csv(amph_precip_summary_t, "results/amph_precip_summary_mean.csv")


#proceed with similar process for other taxa by replacing 'amph' with 'mamm', 'squa' and 'bird'
#this script will give you a datasheet with a column with species names and another column with summary statistics for temperature values
#these datasheets will be used for further analysis
#once all four datasheets are obtained combine them all and save a separate csv file "tetrapod_temp_median.csv" or corresponding to other summary statistics
#this will provide a final datasheet with all tetrapod species and their summary temperatures which will be used for analysis
