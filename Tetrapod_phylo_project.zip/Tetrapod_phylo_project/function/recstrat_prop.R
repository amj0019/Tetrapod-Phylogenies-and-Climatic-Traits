# ---------------------------------------------------------------------------------------#
recstrat_prop <- function(in_grid,sample_no)                                              
{  
  # coded by A.Psomas, Swiss Federal Research Institute WSL, Birmensdorf 
  sample_points <-as.data.frame(matrix(nrow=1,ncol=3)[-1,])	                              
  strata <- sort(na.omit(unique(getValues(in_grid))))                                     
  in_grid_SPixels <- as(in_grid,"SpatialPointsDataFrame")                                 
  names(in_grid_SPixels) <- "layer"
  total_pixels <-nrow(in_grid_SPixels@data)                                               
  strata_stats  <- table(in_grid_SPixels$layer)                                          
  pixels_largest_strata <- max(strata_stats)
  
  result_list <- list()
  for (j in 1:length(strata))                                                             
  {	   
    grid_sel <- in_grid_SPixels[in_grid_SPixels@data[,1] == strata[j] ,]    
    optimal_samples_per_class <- round(log(strata_stats[j])/log(pixels_largest_strata)*(sample_no-1))+1
    points_per_class <- round(min(optimal_samples_per_class, (length(grid_sel)/2)))
    sp_points<-grid_sel[sample(1:nrow(grid_sel),points_per_class,replace=F),]
    sample_points <- cbind(sp_points@coords, strata_id = sp_points@data[,1])
    result_list[[j]] <- sample_points
  }
  result <- data.frame(do.call("rbind", result_list))
  return(result)
}
# ---------------------------------------------------------------------------------------#
